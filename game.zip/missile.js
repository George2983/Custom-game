// Missile class
class Missile {
    constructor(x, y) {
      this.x = x + 5; // Adjust position to align with the jet
      this.y = y + 8; // Adjust position to align with the jet
      this.speed = 7;
      this.width = 10;
      this.height = 5;
      this.color = color(0, 255, 0); // Green color
      this.active = true; // Flag to check if the missile is active
    }
  
    update() {
      if (this.active) {
        this.x += this.speed;
      }
    }
  
    show() {
      if (this.active) {
        fill(this.color);
        rect(this.x, this.y, this.width, this.height);
      }
    }
  
    offscreen() {
      return this.x > width;
    }
  
    hits(obstacle) {
      if (this.active && collideRectRect(this.x, this.y, this.width, this.height, obstacle.x, obstacle.y, obstacle.width, obstacle.height)) {
        this.active = false; // Deactivate missile
        obstacle.destroy(); // Destroy obstacle
        return true;
      }
      return false;
    }
  }
  