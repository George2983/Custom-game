// Jet class
class Jet {
    constructor() {
      this.x = 50;
      this.y = height / 2;
      this.speed = 5;
      this.size = 20; // Size of each pixel
      this.color = color(0, 0, 255); // Blue color
      this.missiles = []; // Array to store active missiles
    }
  
    update() {
      if (keyIsDown(UP_ARROW) && this.y > 0) {
        this.y -= this.speed;
      }
      if (keyIsDown(DOWN_ARROW) && this.y < height - this.size) {
        this.y += this.speed;
      }
    }
  
    show() {
      fill(this.color);
      // Draw the jet using colored pixels
      rect(this.x, this.y, this.size, this.size);
      rect(this.x + this.size, this.y + this.size, this.size, this.size);
      rect(this.x + 2 * this.size, this.y, this.size, this.size);
      rect(this.x + 3 * this.size, this.y, this.size, this.size);
      rect(this.x + 4 * this.size, this.y, this.size, this.size);
      rect(this.x + 2 * this.size, this.y + 2 * this.size, this.size, this.size);
      rect(this.x + this.size, this.y + 3 * this.size, this.size, this.size);
      rect(this.x + 3 * this.size, this.y + 3 * this.size, this.size, this.size);
      rect(this.x + this.size, this.y + 4 * this.size, this.size, this.size);
      rect(this.x + 3 * this.size, this.y + 4 * this.size, this.size, this.size);
  
      // Update and show missiles
      for (let i = this.missiles.length - 1; i >= 0; i--) {
        this.missiles[i].update();
        this.missiles[i].show();
  
        // Remove missiles that are off-screen or inactive
        if (this.missiles[i].offscreen() || !this.missiles[i].active) {
          this.missiles.splice(i, 1);
        }
      }
    }
  
    hits(obstacle) {
      return collideRectRect(this.x, this.y, this.size * 5, this.size * 5, obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    }
  
    shoot() {
      this.missiles.push(new Missile(this.x, this.y)); // Spawn a new missile
    }
  }
  