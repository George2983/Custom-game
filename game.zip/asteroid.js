// Obstacle class
class Obstacle {
    constructor() {
      this.width = 20;
      this.height = 20;
      this.speed = 3;
      this.x = width;
      this.y = random(height - this.height); // Randomize obstacle height
    }
  
    update() {
      this.x -= this.speed;
    }
  
    show() {
      fill(255, 0, 0);
      rect(this.x, this.y, this.width, this.height);
    }
  
    offscreen() {
      return this.x < -this.width;
    }
  
    destroy() {
      // Add any additional logic when the obstacle is destroyed
    }
  }
  