var asteroid1img, asteroid2img, asteroid3img, asteroid4img, asteroidMoving;
var backgroundImg;
var jet;
var obstacles = [];
var missiles = [];
var score = 0;

function preload(){
  asteroid1img = loadImage("./assets/asteroid.jpg");
  asteroid2img = loadImage("./assets/asteroid1.jpg");
  asteroid3img = loadImage("./assets/asteroid2.jpg");
  asteroidMoving = loadAnimation("asteroidMoving", asteroid1img, asteroid2img, asteroid3img);

  backgroundImg = loadImage("./assets/background.jpg");
}

function setup() {
  createCanvas(800, 400);
  jet = new Jet();
}

function draw() {
  background(backgroundImg); // Display background image

  // Update and display the jet
  jet.update();
  jet.show();

  // Generate obstacles randomly
  if (frameCount % 60 === 0) {
    obstacles.push(new Obstacle());
  }

  // Display and update obstacles
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Check for collision with jet
    if (jet.hits(obstacles[i])) {
      console.log('Game Over');
      noLoop(); // Stop the game loop
    }

    // Remove obstacles that are off-screen
    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
      score++; // Increment score when an obstacle passes
    }
  }

  // Display and update missiles
  for (let i = missiles.length - 1; i >= 0; i--) {
    missiles[i].update();
    missiles[i].show();

    // Remove missiles that are off-screen
    if (missiles[i].offscreen()) {
      missiles.splice(i, 1);
    }

    // Check for collision with obstacles
    for (let j = obstacles.length - 1; j >= 0; j--) {
      if (missiles[i].hits(obstacles[j])) {
        score += 5; // Increment score on hitting an obstacle with a missile
        break; // Break the inner loop as the missile is destroyed
      }
    }
  }

  // Display score
  textSize(16);
  fill(255);
  text('Score: ' + score, 20, 20);
}

function keyPressed() {
  if (key === 'SPACE') {
    jet.shoot(); // Spawn a missile when space key is pressed
  }
}
